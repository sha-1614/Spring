package com.ford.cloudnative.gvms.vehicleconfigupdate.helper;

import com.ford.cloudnative.gvms.vehicleconfigupdate.dao.ConfigDidReceiverDao;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

@Component
public class ConfigDidQueueHelper {

    @Autowired
    private ConfigDidReceiverDao configDidReceiverDao;

    private static Queue<ConfigDidReceiver> configDidReceiverQueue = new LinkedList<>();

    private static Logger log = LoggerFactory.getLogger(ConfigDidQueueHelper.class);

    public void pollElement() {
        if (configDidReceiverQueue.size() > 0) {
            ConfigDidReceiver configDidReceiver = configDidReceiverQueue.poll();
            log.info("Element removed from queue " + configDidReceiver.getTraceId());
        }
    }

    public ConfigDidReceiver getHeadElementFromQueue() {
        ConfigDidReceiver headElement = null;
        if (configDidReceiverQueue.size() > 0) {
            headElement = configDidReceiverQueue.peek();
        }
        return headElement;
    }

    public int getCurrentQueueSize() {
        return configDidReceiverQueue.size();
    }

    public boolean loadConfigDidFeedsIntoQueue(List<ConfigDidReceiver> configDidReceiverList) {
        return configDidReceiverQueue.addAll(configDidReceiverList);
    }
}
