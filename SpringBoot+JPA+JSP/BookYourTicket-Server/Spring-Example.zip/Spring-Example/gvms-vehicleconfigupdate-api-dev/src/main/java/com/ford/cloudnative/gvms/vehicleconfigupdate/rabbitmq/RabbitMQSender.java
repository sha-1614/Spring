package com.ford.cloudnative.gvms.vehicleconfigupdate.rabbitmq;

import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQSender {
	
	@Autowired
	private AmqpTemplate amqpTemplate;

	@Autowired
	VehicleConfigPropertyReader propertyReader;

	public void send(String message) {
		amqpTemplate.convertAndSend(propertyReader.getExchange(), propertyReader.getRoutingKey(), message);
	}
}