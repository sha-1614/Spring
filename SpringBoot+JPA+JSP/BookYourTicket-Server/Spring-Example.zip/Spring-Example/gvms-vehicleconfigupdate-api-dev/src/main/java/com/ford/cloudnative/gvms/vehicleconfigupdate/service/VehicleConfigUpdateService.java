package com.ford.cloudnative.gvms.vehicleconfigupdate.service;

import com.ford.cloudnative.gvms.vehicleconfigupdate.dao.ConfigDidReceiverDao;
import com.ford.cloudnative.gvms.vehicleconfigupdate.exception.ConfigDidReceiverException;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.HttpServerHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.RabbitMQHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.VehicleConfigDidRequest;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.SnapValidatorReqHandler;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VinDidValidator;
import com.google.gson.Gson;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Service
public class VehicleConfigUpdateService {

    @Autowired
    private SnapValidatorReqHandler snapValidatorReqHandler;
    @Autowired
    ConfigDidReceiverDao configDidReceiverDao;
    @Autowired
    HttpServerHelper httpServerHelper;
    @Autowired
    VehicleConfigPropertyReader vehicleConfigPropertyReader;
    @Autowired
    RabbitMQHelper rabbitMQHelper;

    private static Logger log = LoggerFactory.getLogger(VinDidValidator.class);
    Gson gson = new Gson();

    public void processVehConfigDidRequest(ConfigDidReceiver configDidReceiver) throws ConfigDidReceiverException {
        VehicleConfigDidRequest vehicleConfigDidRequest = gson.fromJson(configDidReceiver.getData(), VehicleConfigDidRequest.class);
        boolean isQueueUnoccupied = rabbitMQHelper.checkIsRMQProcessingEvents();
        if (isQueueUnoccupied) {
            removeProcessedEventFromTable();
            List<String> snapValidatorReqList = prepareSnapValidatorInput(vehicleConfigDidRequest);
            snapValidatorReqHandler.pushToRabbitMq(snapValidatorReqList);
            updateConfigEventStatus(vehicleConfigDidRequest.getTraceId());
        } else {
            log.info("RMQ still processing earlier events - New event not published");
        }
    }

    private List<String> prepareSnapValidatorInput(VehicleConfigDidRequest vehicleConfigDidRequest) {
        log.info("prepareSnapValidatorInput method triggered");
        Instant start = Instant.now();
        Integer itemCount = vehicleConfigDidRequest.getItemCount();
        Integer uniqueVinCount = vehicleConfigDidRequest.getUniqueVinCount();
        int duplicateVINCount = itemCount - uniqueVinCount;
        log.info("itemCount::" + itemCount + " uniqueVinCount::" + uniqueVinCount + " duplicateVINCount::" + duplicateVINCount);

        // Validate VINs from json request if any VIN is not valid
        // If true then record will be removed from config update request
        VinDidValidator.validateVehicleConfigDidReq(vehicleConfigDidRequest);
        if (duplicateVINCount > 0) {
            consolidateVehicleConfigDidReq(vehicleConfigDidRequest);
        }
        // Prepare Analyze Log JSON Request from VIL request
        List<String> snapValidatorReqList = snapValidatorReqHandler.prepareALRequest(vehicleConfigDidRequest);
        log.info("snapValidatorReqList :: " + snapValidatorReqList);

        Instant end = Instant.now();
        log.info("prepareSnapValidatorInput method execution time ::" + Duration.between(start, end).getNano() + "ms");
        return snapValidatorReqList;
    }

    private void consolidateVehicleConfigDidReq(VehicleConfigDidRequest vehicleConfigDidRequest) {
        log.info("mergeDuplicateVINConfiguration method triggered");
        Instant start = Instant.now();
        VinDidValidator.consolidateGvmsConfiguration(vehicleConfigDidRequest);
        Instant end = Instant.now();
        log.info("mergeDuplicateVINConfiguration method execution time ::" + (Duration.between(start, end).getNano() / 1000000) + "ms");
    }

    public void storeConfigDidBatch(JsonObject configDidRequest) throws ConfigDidReceiverException {
        ConfigDidReceiver receiver = new ConfigDidReceiver();
        String traceId = configDidRequest.getString("traceId");
        log.info("received feed :" + traceId);
        receiver.setData(configDidRequest.toString());
        receiver.setTraceId(traceId);
        receiver.setStatus(VehicleConfigUpdateConstants.CONFIG_RECV_NOT_IN_QUEUE_STATUS);
        receiver.setCreatedDate(new Date());
        try {
            ConfigDidReceiver storedObj = configDidReceiverDao.save(receiver);
            if (null == storedObj)
                throw new ConfigDidReceiverException("Config did batch not stored in DB");
        } catch (Exception e) {
            throw new ConfigDidReceiverException(e.getMessage());
        }
    }

    public void removeProcessedEventFromTable() {
        ConfigDidReceiver configDidReceiver = configDidReceiverDao.findByStatus(VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
        if (null != configDidReceiver) {
            configDidReceiverDao.delete(configDidReceiver);
            log.info("config receiver feed deleted successfully - " + configDidReceiver.getTraceId());
        } else {
            log.info("no records found with status - " + VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
        }
    }

    private void updateConfigEventStatus(String traceId) {
        ConfigDidReceiver configDidReceiver = configDidReceiverDao.findByTraceId(traceId);
        if (null != configDidReceiver) {
            configDidReceiver.setStatus(VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
            configDidReceiverDao.save(configDidReceiver);
            log.info("config receiver feed deleted successfully - " + configDidReceiver.getTraceId());
        }
    }
}
