package com.ford.cloudnative.gvms.vehicleconfigupdate.json;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VehicleConfigDidRequest {

    @SerializedName("gvmsConfigurations")
    @Expose
    private List<GvmsConfiguration> gvmsConfigurations = null;
    @SerializedName("traceId")
    @Expose
    private String traceId;
    @SerializedName("uniqueVinCount")
    @Expose
    private Integer uniqueVinCount;
    @SerializedName("itemCount")
    @Expose
    private Integer itemCount;
    @SerializedName("isConsolidated")
    @Expose
    private Boolean isConsolidated;

    public List<GvmsConfiguration> getGvmsConfigurations() {
        return gvmsConfigurations;
    }

    public void setGvmsConfigurations(List<GvmsConfiguration> gvmsConfigurations) {
        this.gvmsConfigurations = gvmsConfigurations;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public Integer getUniqueVinCount() {
        return uniqueVinCount;
    }

    public void setUniqueVinCount(Integer uniqueVinCount) {
        this.uniqueVinCount = uniqueVinCount;
    }

    public Integer getItemCount() {
        return itemCount;
    }

    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    public Boolean getIsConsolidated() {
        return isConsolidated;
    }

    public void setIsConsolidated(Boolean isConsolidated) {
        this.isConsolidated = isConsolidated;
    }
}

