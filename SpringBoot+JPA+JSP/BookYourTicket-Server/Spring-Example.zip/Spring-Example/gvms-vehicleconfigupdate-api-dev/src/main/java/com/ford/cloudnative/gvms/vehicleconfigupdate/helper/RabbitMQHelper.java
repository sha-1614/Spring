package com.ford.cloudnative.gvms.vehicleconfigupdate.helper;

import com.ford.cloudnative.gvms.vehicleconfigupdate.exception.ConfigDidReceiverException;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import com.rabbitmq.http.client.Client;
import com.rabbitmq.http.client.ClientParameters;
import com.rabbitmq.http.client.domain.QueueInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.time.Duration;
import java.time.Instant;

@Component
public class RabbitMQHelper {

    @Autowired
    VehicleConfigPropertyReader propertyReader;

    private static final String RMQ_HOST_CONSTANT = "<localhost>";
    private static final String RMQ_PORT_CONSTANT = "<port>";
    private static final String URL_APPENED = "http://<localhost>:<port>/api/";

    private static Logger log = LoggerFactory.getLogger(RabbitMQHelper.class);

    private Client client = null;
    private QueueInfo queue = null;


    public boolean checkIsRMQProcessingEvents() throws ConfigDidReceiverException {
        Instant start = Instant.now();
        Long totalMessageCountFromQueue = getTotalMessageCountFromQueue();
        Instant end = Instant.now();
        log.info("checkRMQProcessingEvents method execution time ::" + (Duration.between(start, end).getNano() / 1000000) + "ms");
        return (totalMessageCountFromQueue == 0);
    }

    public Long getTotalMessageCountFromQueue() throws ConfigDidReceiverException {
        Long totalMessageInQueue = 0L;
        connectRmqApiManagement();
        QueueInfo queue = getQueue();
        if (queue == null)
            return 0L;
        long messagesUnacknowledged = queue.getMessagesUnacknowledged();
        long messageReady = queue.getMessagesReady();
        totalMessageInQueue = messagesUnacknowledged + messageReady;
        log.info("messagesUnacknowledged :: " + messagesUnacknowledged + " messageReady :: " + messageReady + " totalMessageInQueue ::" + totalMessageInQueue);
        return totalMessageInQueue;
    }

    public QueueInfo getQueue() throws ConfigDidReceiverException {
        if (this.client == null) {
            loadRMQClient();
        }
        queue = client.getQueue(propertyReader.getVirtualHost(), propertyReader.getQueueName());
        return queue;
    }

    public Client loadRMQClient() throws ConfigDidReceiverException {
        connectRmqApiManagement();
        return this.client;
    }

    private void connectRmqApiManagement() throws ConfigDidReceiverException {
        String rmqClientUrl = URL_APPENED.replace(RMQ_HOST_CONSTANT, propertyReader.getHost()).
                replace(RMQ_PORT_CONSTANT, propertyReader.getRmqServerPort());
        try {
            client = new Client(new ClientParameters()
                    .url(rmqClientUrl)
                    .username(propertyReader.getUserName())
                    .password(propertyReader.getPassword()));
        } catch (URISyntaxException | MalformedURLException e) {
            throw new ConfigDidReceiverException("Exception in RMQ client connection :: " + e.getMessage());
        }
    }

}


