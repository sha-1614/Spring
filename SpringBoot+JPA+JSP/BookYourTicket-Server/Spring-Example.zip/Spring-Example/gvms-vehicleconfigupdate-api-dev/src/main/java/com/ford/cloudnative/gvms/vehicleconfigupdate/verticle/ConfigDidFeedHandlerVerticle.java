package com.ford.cloudnative.gvms.vehicleconfigupdate.verticle;

import com.ford.cloudnative.gvms.vehicleconfigupdate.exception.ConfigDidReceiverException;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.ConfigDidQueueHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.RabbitMQHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import com.ford.cloudnative.gvms.vehicleconfigupdate.service.VehicleConfigUpdateRepoHandler;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.EventBus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ConfigDidFeedHandlerVerticle extends AbstractVerticle {

    @Autowired
    ConfigDidQueueHelper queueHelper;
    @Autowired
    RabbitMQHelper rabbitMQHelper;
    @Autowired
    VehicleConfigUpdateRepoHandler repoHandler;

    private static final Object DEFAULT_REPLY_MESSAGE = "Received";
    private static final String CONSOLIDATE_VERTICLE_ADDR = "consolidateVerticle";
    private static final String CONFIG_FEED_RUNNER_ADDR = "configFeedRunner";

    private Logger log = LoggerFactory.getLogger(ConfigDidFeedHandlerVerticle.class);

    @Override
    public void start() {
        final EventBus eventBus = vertx.eventBus();
        eventBus.consumer(CONFIG_FEED_RUNNER_ADDR, receivedMessage -> {
            log.info("Received message: " + receivedMessage.body());
            try {
                boolean isFeedEnqueued = loadInMemoryQueueIfEmpty();
                log.info("isFeedEnqueued - " + isFeedEnqueued);
                if (isFeedEnqueued)
                    pushToRabbitMQ();
            } catch (ConfigDidReceiverException e) {
                log.error("Exception in ConfigDidFeedHandlerVerticle -" + e.getMessage());
            }
            receivedMessage.reply(DEFAULT_REPLY_MESSAGE);
        });
    }

    private boolean loadInMemoryQueueIfEmpty() {
        int currentQueueSize = queueHelper.getCurrentQueueSize();
        if (currentQueueSize != 0) {
            return true;
        }
        List<ConfigDidReceiver> configDidFeedsList = repoHandler.fetchConfigDidFeedsWithStatus(VehicleConfigUpdateConstants.CONFIG_RECV_NOT_IN_QUEUE_STATUS);
        if (null != configDidFeedsList) {
            log.info("Number of records fetch from table - " + configDidFeedsList.size());
            return queueHelper.loadConfigDidFeedsIntoQueue(configDidFeedsList);
        }
        return false;
    }

    private void pushToRabbitMQ() throws ConfigDidReceiverException {
        boolean isQueueAvailable = rabbitMQHelper.checkIsRMQProcessingEvents();
        log.info("isQueueAvailable ::" + isQueueAvailable);
        if (isQueueAvailable) {
            repoHandler.removeProcessedEventFromTable();
            triggerEventConsolidation();
        }
    }

    private void triggerEventConsolidation() {
        vertx.eventBus().send(CONSOLIDATE_VERTICLE_ADDR, null);
    }
}
