package com.ford.cloudnative.gvms.vehicleconfigupdate.json;

import java.util.List;

public class OemConfig {

    private String ECUId;
    private String partIIPartNumber;
    private List<DIDConfiguration> didConfiguration;

    public String getECUId() {
        return ECUId;
    }

    public void setECUId(String ECUId) {
        this.ECUId = ECUId;
    }

    public List<DIDConfiguration> getDidConfiguration() {
        return didConfiguration;
    }

    public void setDidConfiguration(List<DIDConfiguration> didConfiguration) {
        this.didConfiguration = didConfiguration;
    }


    public String getPartIIPartNumber() {
        return partIIPartNumber;
    }

    public void setPartIIPartNumber(String partIIPartNumber) {
        this.partIIPartNumber = partIIPartNumber;
    }

    @Override
    public String toString() {
        //{"ECUId":1876,"partIIPartNumber":"DSJX7T-14G087-AK","didConfiguration":[{"DIDAddress":64813,"DIDConfigData":"RxAC","didType":"OTHER"}]}VIN : WF0JXXGAHJKY18246
        StringBuffer ecuConfig = new StringBuffer();
        ecuConfig.append("{ECUId\":" + getECUId() + " , \"partIIPartNumber\" :" + getPartIIPartNumber() + ",");
        ecuConfig.append("\"didConfiguration\":[");
        for (int i = 0; didConfiguration != null && i < didConfiguration.size(); i++) {
            DIDConfiguration didConfig = didConfiguration.get(i);
            ecuConfig.append("{\"DIDAddress\":" + didConfig.getDIDAddress()
                    + " , \"DIDConfigData\" :" + didConfig.getDIDConfigData()
                    + " , \"didType\" :" + didConfig.getDidType()
                    + "}");
            if (didConfiguration.size() > 1 && (i + 1 < didConfiguration.size())) {
                ecuConfig.append(",");
            }
        }
        ecuConfig.append("}]}");


        return ecuConfig.toString();
        //return ,didConfiguration:[{DIDAddress:"+64813,"DIDConfigData":"RxAC","didType":"OTHER"}]}";
    }
}

