package com.ford.cloudnative.gvms.vehicleconfigupdate.util;

//import com.ford.cloudnative.gvms.vehicleconfigupdate.json.ConfigList;

import com.ford.cloudnative.gvms.vehicleconfigupdate.json.DIDConfiguration;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.GvmsConfiguration;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.OemConfig;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.VehicleConfigDidRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;


public class VinDidValidator {

    private static Logger log = LoggerFactory.getLogger(VinDidValidator.class);

    public static Boolean validateVIN(String vin) {
        Boolean isVinValid = true;
        if ((vin == null || "".equalsIgnoreCase(vin) || vin.length() != 17 || !vin.substring(vin.length() - 2).matches("[0-9]+")))
            isVinValid = false;
        return isVinValid;
    }

    // Process vehicle config update request if same VIN-ESN presented more than once then config DIDs will be merged into one record
    public static void consolidateGvmsConfiguration(VehicleConfigDidRequest vehicleConfigDidRequest) {
        Map<String, OemConfig> oemConfigurationMap = new HashMap();
        List<GvmsConfiguration> gvmsConfigurations = vehicleConfigDidRequest.getGvmsConfigurations();
        Collections.sort(gvmsConfigurations);
        gvmsConfigurations.stream().forEach(gvmsConfiguration -> {
            VinDidValidator.consolidateOemConfigDid(gvmsConfiguration, oemConfigurationMap);
        });
        vehicleConfigDidRequest.getGvmsConfigurations().removeIf(gvmsConfiguration ->
                gvmsConfiguration.getOemConfig().isEmpty()
        );
    }


    public static void consolidateOemConfigDid(GvmsConfiguration gvmsConfiguration, Map<String, OemConfig> vinConfigurationMap) {
        List<OemConfig> oemConfigList = gvmsConfiguration.getOemConfig();
        for (int i = 0; i < oemConfigList.size(); i++) {
            String vilLookUpKey = gvmsConfiguration.getVin() + "_" + oemConfigList.get(i).getECUId();
            boolean isDuplicate = checkExistenceInMap(vilLookUpKey, oemConfigList.get(i), vinConfigurationMap);
            if (isDuplicate)
                oemConfigList.remove(i);
        }
    }

    private static boolean checkExistenceInMap(String vilLookUpKey, OemConfig oemConfig, Map<String, OemConfig> vinConfigurationMap) {
        if (!vinConfigurationMap.containsKey(vilLookUpKey)) {
            vinConfigurationMap.put(vilLookUpKey, oemConfig);
        } else {
            OemConfig oemConfig1 = vinConfigurationMap.get(vilLookUpKey);
            List<DIDConfiguration> didConfiguration = oemConfig.getDidConfiguration();
            oemConfig1.getDidConfiguration().addAll(didConfiguration);
            return true;
        }
        return false;
    }

    public static void validateVehicleConfigDidReq(VehicleConfigDidRequest vehicleConfigDidRequest) {
        List<GvmsConfiguration> gvmsConfigurations = vehicleConfigDidRequest.getGvmsConfigurations();
        gvmsConfigurations.parallelStream().forEach(gvmsConfiguration -> {
            String errorMsg = null;
            String status = null;
            if (gvmsConfiguration.getVin() == null || !validateVIN(gvmsConfiguration.getVin())) {
                errorMsg = "Config DID : No VIN in the TMC response";
                status = VehicleConfigUpdateConstants.CFG_NO_VIN;
            }
            if (gvmsConfiguration.getOemConfig() == null) {
                errorMsg = "Config DID : No OEMConfig in the TMC response";
                status = VehicleConfigUpdateConstants.CFG_NO_OEMCONFIG;
            }
            log.info("validateVehicleConfigDidReq :: errorMsg :: " + errorMsg + " status ::" + status);
        });
    }
}
