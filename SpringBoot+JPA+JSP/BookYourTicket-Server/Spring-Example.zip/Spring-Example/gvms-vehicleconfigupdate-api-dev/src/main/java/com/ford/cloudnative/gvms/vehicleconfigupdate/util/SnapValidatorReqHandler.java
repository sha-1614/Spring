package com.ford.cloudnative.gvms.vehicleconfigupdate.util;

import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.HttpServerHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.RabbitMQHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.GvmsConfiguration;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.VehicleConfigDidRequest;
import com.ford.cloudnative.gvms.vehicleconfigupdate.rabbitmq.RabbitMQSender;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@Component
public class SnapValidatorReqHandler {

    @Autowired
    VehicleConfigPropertyReader propertyReader;

    @Autowired
    HttpServerHelper httpServerHelper;

    @Autowired
    VehicleConfigUpdateConstants constants;

    @Autowired
    RabbitMQSender rabbitMQSender;

    @Autowired
    RabbitMQHelper rabbitMQHelper;

    private static String RMQ_HOST_CONSTANT = "<localhost>";
    private static String RMQ_PORT_CONSTANT = "<port>";
    private static String URL_APPENED = "http://<localhost>:<port>/api/";

    private static Logger log = LoggerFactory.getLogger(SnapValidatorReqHandler.class);
    private static Boolean isALServiceRequired = Boolean.TRUE;
    Gson gson = new Gson();

    public List<String> prepareALRequest(VehicleConfigDidRequest vehicleConfigDidRequest) {
        List<GvmsConfiguration> gvmsConfigurations = vehicleConfigDidRequest.getGvmsConfigurations();
        List<String> snapValidatorReqList = new ArrayList<>();
        for (GvmsConfiguration gvmsConfiguration : gvmsConfigurations) {
            String snapValidatorRequest = gson.toJson(gvmsConfiguration);
            snapValidatorReqList.add(snapValidatorRequest);
        }
        return snapValidatorReqList;
    }

    public void pushToRabbitMq(List<String> snapValidatorRequest) {
        snapValidatorRequest.stream().forEach(rabbitMQSender::send);
    }

}
