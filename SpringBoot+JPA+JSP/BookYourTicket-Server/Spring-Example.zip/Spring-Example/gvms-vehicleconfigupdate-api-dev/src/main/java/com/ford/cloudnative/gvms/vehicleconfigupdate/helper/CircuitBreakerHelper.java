package com.ford.cloudnative.gvms.vehicleconfigupdate.helper;

import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import io.vertx.circuitbreaker.CircuitBreaker;
import io.vertx.circuitbreaker.CircuitBreakerOptions;
import io.vertx.core.Vertx;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CircuitBreakerHelper {

    @Autowired
    VehicleConfigPropertyReader propertyReader;

    public CircuitBreaker loadCircuitBreaker(Vertx vertx) {
        return CircuitBreaker.create(propertyReader.getCircuitBreakerName(), vertx,
                new CircuitBreakerOptions()
                        .setMaxFailures(propertyReader.getCircuitBreakerFailureCount())
                        .setTimeout(propertyReader.getCircuitBreakerTimeout())
                        .setFallbackOnFailure(propertyReader.getCircuitBreakerFallBackOnFailure())
                        .setResetTimeout(propertyReader.getCircuitBreakerResetTimeout())
        );
    }
}
