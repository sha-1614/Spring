package com.ford.cloudnative.gvms.vehicleconfigupdate.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class VehicleConfigUpdateConstants {

    public static final String CFG_NO_VIN = "VEH_CONFUPD-101";
    public static final String CFG_NO_OEMCONFIG = "VEH_CONFUPD-102";

    public static final String CONFIG_RECV_IN_QUEUE_STATUS = "inqueue";
    public static final String CONFIG_RECV_NOT_IN_QUEUE_STATUS = "notinqueue";

    public static final String CFG_SUCCESS = "SUCCESS";
    public static final String CFG_FAILURE = "FAILURE";

//    Error response
    public static final String EMPTY_REQUEST_ERR = "Request should not be empty";

    public static final String HTTP_CONTENT_TYPE = "Content-Type";
    public static final String HTTP_JSON_TYPE = "Content-Type";
}
