package com.ford.cloudnative.gvms.vehicleconfigupdate.verticle;

import com.ford.cloudnative.gvms.vehicleconfigupdate.exception.ConfigDidReceiverException;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.CircuitBreakerHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.HttpServerHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.RouterHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.service.VehicleConfigUpdateService;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import io.vertx.circuitbreaker.CircuitBreaker;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RestServerVerticle extends AbstractVerticle {


    private static Logger log = LoggerFactory.getLogger(RestServerVerticle.class);

    @Autowired
    VehicleConfigUpdateService vehicleConfigUpdateService;

    @Autowired
    CircuitBreakerHelper circuitBreakerHelper;

    CircuitBreaker circuitBreaker = null;

    /**
     * @param promise
     */
    @Override
    public void start(Promise<Void> promise) {
        String x= "gedsad\n".replaceAll("[\\n]","");
        log.info(x);
        final Router router = RouterHelper.createRouter(vertx);
        circuitBreaker = circuitBreakerHelper.loadCircuitBreaker(vertx);

        // Endpoint used to check app health
        router.get("/").handler(routingContext -> {
            routingContext.response().end("Application running ..!");
        });

        // Registering path in router handler to handle requests asynchronously, This handler triggers for each request.
        router.post("/api/vehicleconfigupdate/processbatch").handler(this::configDidBatchHandler);

//        router.delete("/api/vehicleconfigupdate/configreceiversuccess").handler(this::performCallbackProcess);
        HttpServerHelper.createAnHttpServer(vertx, router, config(), 8080, promise);
    }

    /**
     * @param routingContext
     */
    private void configDidBatchHandler(RoutingContext routingContext) {
        circuitBreaker.execute(promise -> {
                    String response = processConfigDidEvents(routingContext);
                    if (!response.equalsIgnoreCase(VehicleConfigUpdateConstants.CFG_SUCCESS)) {
                        promise.fail(response);
                    } else {
                        promise.complete(VehicleConfigUpdateConstants.CFG_SUCCESS);
                    }
                }
        ).onSuccess(res -> {
            routingContext.response().end(res.toString());
        }).onFailure(failure -> {
            routingContext.response().end(failure.getMessage());
        });
    }

    private String processConfigDidEvents(RoutingContext routingContext) {
        String response = null;
        JsonObject requestJson = routingContext.getBodyAsJson();
        try {
            if (requestJson == null || requestJson.isEmpty()) {
                response = VehicleConfigUpdateConstants.EMPTY_REQUEST_ERR;
            } else {
                vehicleConfigUpdateService.storeConfigDidBatch(requestJson);
                response = VehicleConfigUpdateConstants.CFG_SUCCESS;
            }
        } catch (ConfigDidReceiverException e) {
            log.error("Exception in configDidBatchHandler : " + e.getMessage());
            response = e.getMessage();
        }
        return response;
    }

//    private void performCallbackProcess(RoutingContext routingContext) {
//        String response = null;
//        String correlationId = routingContext.request().getParam("correlationid");
//        boolean isFeedRemoved = vehicleConfigUpdateService.removeProcessedBatch();
//        if (isFeedRemoved) {
//            response = "Success";
//        } else {
//            response = "Record not found with given correlation id -" + correlationId;
//        }
//        routingContext.response().end(response);
//    }

}
