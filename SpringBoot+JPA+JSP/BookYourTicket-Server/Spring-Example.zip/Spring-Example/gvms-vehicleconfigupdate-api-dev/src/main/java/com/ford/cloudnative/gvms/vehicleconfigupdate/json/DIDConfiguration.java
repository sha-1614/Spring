package com.ford.cloudnative.gvms.vehicleconfigupdate.json;

public class DIDConfiguration {

    private String DIDAddress;
    private String DIDConfigData;
    private String didType;

    public String getDIDAddress() {
        return Integer.toHexString(Integer.valueOf(DIDAddress));
    }

    public void setDIDAddress(String DIDAddress) {
        this.DIDAddress = DIDAddress;
    }

    public String getDIDConfigData() {
        return DIDConfigData;
    }

    public void setDIDConfigData(String DIDConfigData) {

        this.DIDConfigData = DIDConfigData;
    }

    public String getDidType() {
        return didType;
    }

    public void setDidType(String didType) {
        this.didType = didType;
    }

}

