package com.ford.cloudnative.gvms.vehicleconfigupdate.helper;

import io.vertx.core.Vertx;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.ext.web.handler.TimeoutHandler;

public class RouterHelper {

    public static Router createRouter(final Vertx vertx) {
        final Router router = Router.router(vertx);
        router.route().handler(TimeoutHandler.create(20000));
        router.route().handler(BodyHandler.create());
        return router;
    }
}
