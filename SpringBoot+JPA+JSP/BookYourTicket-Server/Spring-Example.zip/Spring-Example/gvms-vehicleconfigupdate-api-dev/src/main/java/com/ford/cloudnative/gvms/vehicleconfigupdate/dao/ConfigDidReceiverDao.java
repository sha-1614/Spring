package com.ford.cloudnative.gvms.vehicleconfigupdate.dao;

import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConfigDidReceiverDao extends CrudRepository<ConfigDidReceiver, Long> {

    ConfigDidReceiver findByTraceId(String traceId);

    List<ConfigDidReceiver> findFirst10ByStatusOrderByCreatedDateAsc(String status);

    ConfigDidReceiver findByStatus(String status);
}
