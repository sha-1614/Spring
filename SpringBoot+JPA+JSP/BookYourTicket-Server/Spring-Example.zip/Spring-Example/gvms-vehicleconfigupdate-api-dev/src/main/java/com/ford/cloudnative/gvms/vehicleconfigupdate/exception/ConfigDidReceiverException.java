package com.ford.cloudnative.gvms.vehicleconfigupdate.exception;

public class ConfigDidReceiverException extends Exception {

    String exception = null;

    public ConfigDidReceiverException(String exception) {
        super(exception);
        this.exception = exception;
    }

}
