package com.ford.cloudnative.gvms.vehicleconfigupdate.helper;

import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VinDidValidator;
import io.vertx.core.Promise;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HttpServerHelper {

    private static Logger log = LoggerFactory.getLogger(VinDidValidator.class);

    RestTemplate oauthRestTemplate = new RestTemplate();

    /**
     * @param vertx
     * @param router
     * @param config
     * @param port
     * @param promise
     */
    public static void createAnHttpServer(final Vertx vertx, final Router router, final JsonObject config,
                                          final int port, final Promise<Void> promise) {
        vertx.createHttpServer().requestHandler(router)
                .listen(config.getInteger("http.port", port), result -> {
                    if (result.succeeded()) {
                        log.info("HTTP server running on port {} " + port);
                        promise.complete();
                    } else {
                        log.info("Could not start a HTTP server" + result.cause());
                        promise.fail(result.cause());
                    }
                });
    }
}
