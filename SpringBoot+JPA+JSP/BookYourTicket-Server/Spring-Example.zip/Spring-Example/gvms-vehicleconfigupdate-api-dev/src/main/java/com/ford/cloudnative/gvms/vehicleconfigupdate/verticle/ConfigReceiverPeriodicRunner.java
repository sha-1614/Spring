package com.ford.cloudnative.gvms.vehicleconfigupdate.verticle;

import com.ford.cloudnative.gvms.vehicleconfigupdate.dao.ConfigDidReceiverDao;
import com.ford.cloudnative.gvms.vehicleconfigupdate.exception.ConfigDidReceiverException;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import com.ford.cloudnative.gvms.vehicleconfigupdate.service.VehicleConfigUpdateService;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import io.vertx.core.AbstractVerticle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ConfigReceiverPeriodicRunner extends AbstractVerticle {

    @Autowired
    VehicleConfigUpdateService vehicleConfigUpdateService;

    @Autowired
    VehicleConfigPropertyReader vehicleConfigPropertyReader;

    @Autowired
    ConfigDidReceiverDao configDidReceiverDao;

    private static final String CONFIG_FEED_RUNNER_ADDR = "configFeedRunner";
    private static final String CONSOLIDATE_VERTICLE_ADDR = "consolidateVerticle";

    private Long periodicDelayInMs = 0L;
    private Logger log = LoggerFactory.getLogger(ConfigReceiverPeriodicRunner.class);
    private Long timerId = null;

    @Override
    public void start() {
        periodicDelayInMs = vehicleConfigPropertyReader.getPeriodicRunnerDelayInMs();
        timerId = vertx.setPeriodic(periodicDelayInMs, timerId -> {
            log.info("Periodic process triggered");
            triggerFeedHandlerVerticle();
//            startBatchProcess();
            log.info("Periodic process completed");
        });
    }

    private void triggerFeedHandlerVerticle() {
        vertx.eventBus().send(CONFIG_FEED_RUNNER_ADDR, null);
    }

    private void startBatchProcess() {
        List<ConfigDidReceiver> configDidRequest = configDidReceiverDao.findFirst10ByStatusOrderByCreatedDateAsc(VehicleConfigUpdateConstants.CONFIG_RECV_NOT_IN_QUEUE_STATUS);
        if (null != configDidRequest) {
            log.info("Record loaded : traceId :" + configDidRequest.get(0).getTraceId() + " feed:" + configDidRequest);
            try {
                vehicleConfigUpdateService.processVehConfigDidRequest(configDidRequest.get(0));
            } catch (ConfigDidReceiverException e) {
                log.error(e.getMessage());
            }
        }
    }

}
