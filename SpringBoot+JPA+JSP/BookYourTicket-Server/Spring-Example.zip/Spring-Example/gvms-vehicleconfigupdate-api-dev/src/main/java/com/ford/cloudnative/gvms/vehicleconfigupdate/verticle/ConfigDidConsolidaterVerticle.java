package com.ford.cloudnative.gvms.vehicleconfigupdate.verticle;

import com.ford.cloudnative.gvms.vehicleconfigupdate.helper.ConfigDidQueueHelper;
import com.ford.cloudnative.gvms.vehicleconfigupdate.json.VehicleConfigDidRequest;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import com.ford.cloudnative.gvms.vehicleconfigupdate.service.VehicleConfigUpdateRepoHandler;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.SnapValidatorReqHandler;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VinDidValidator;
import com.google.gson.Gson;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.eventbus.MessageConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class ConfigDidConsolidaterVerticle extends AbstractVerticle {

    @Autowired
    private SnapValidatorReqHandler snapValidatorReqHandler;
    @Autowired
    ConfigDidQueueHelper queueHelper;
    @Autowired
    VehicleConfigUpdateRepoHandler repoHandler;

    final private Gson gson = new Gson();
    private static final Object DEFAULT_REPLY_MESSAGE = "Received";
    private static final String CONSOLIDATE_VERTICLE_ADDR = "consolidateVerticle";
    private Logger log = LoggerFactory.getLogger(ConfigDidConsolidaterVerticle.class);

    @Override
    public void start() {
        final EventBus eventBus = vertx.eventBus();
        MessageConsumer<Object> consumer = eventBus.consumer(CONSOLIDATE_VERTICLE_ADDR, receivedMessage -> {
            ConfigDidReceiver configDidEventFeed = queueHelper.getHeadElementFromQueue();
            VehicleConfigDidRequest vehicleConfigDidRequest = gson.fromJson(configDidEventFeed.getData(), VehicleConfigDidRequest.class);
            List<String> snapValidatorReqList = prepareSnapValidatorInput(vehicleConfigDidRequest);
            snapValidatorReqHandler.pushToRabbitMq(snapValidatorReqList);
            updateConfigEventFeedStatus(vehicleConfigDidRequest.getTraceId());
            receivedMessage.reply(DEFAULT_REPLY_MESSAGE);
        });
    }

    private List<String> prepareSnapValidatorInput(VehicleConfigDidRequest vehicleConfigDidRequest) {
        log.info("prepareSnapValidatorInput method triggered");
        Instant start = Instant.now();
        Integer itemCount = vehicleConfigDidRequest.getItemCount();
        Integer uniqueVinCount = vehicleConfigDidRequest.getUniqueVinCount();
        int duplicateVINCount = itemCount - uniqueVinCount;
        log.info("itemCount::" + itemCount + " uniqueVinCount::" + uniqueVinCount + " duplicateVINCount::" + duplicateVINCount);

        // Validate VINs from json request if any VIN is not valid
        // If true then record will be removed from config update request
        VinDidValidator.validateVehicleConfigDidReq(vehicleConfigDidRequest);
        if (duplicateVINCount > 0) {
            VinDidValidator.consolidateGvmsConfiguration(vehicleConfigDidRequest);
        }
        // Prepare Analyze Log JSON Request from VIL request
        List<String> snapValidatorReqList = snapValidatorReqHandler.prepareALRequest(vehicleConfigDidRequest);
        log.info("snapValidatorReqList :: " + snapValidatorReqList);

        Instant end = Instant.now();
        log.info("prepareSnapValidatorInput method execution time ::" + (Duration.between(start, end).getNano() / 1000000) + "ms");
        return snapValidatorReqList;
    }

    private void updateConfigEventFeedStatus(String traceId) {
        ConfigDidReceiver configDidReceiver = repoHandler.findByTraceId(traceId);
        queueHelper.pollElement();
        if (null != configDidReceiver) {
            configDidReceiver.setStatus(VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
            repoHandler.save(configDidReceiver);
            log.info(configDidReceiver.getTraceId() + " config receiver feed status changed to " + VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
        }
    }

}
