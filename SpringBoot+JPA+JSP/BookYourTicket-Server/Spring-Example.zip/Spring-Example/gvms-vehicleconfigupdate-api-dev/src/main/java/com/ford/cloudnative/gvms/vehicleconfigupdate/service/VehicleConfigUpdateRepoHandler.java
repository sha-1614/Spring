package com.ford.cloudnative.gvms.vehicleconfigupdate.service;

import com.ford.cloudnative.gvms.vehicleconfigupdate.dao.ConfigDidReceiverDao;
import com.ford.cloudnative.gvms.vehicleconfigupdate.model.ConfigDidReceiver;
import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigUpdateConstants;
import com.ford.cloudnative.gvms.vehicleconfigupdate.verticle.ConfigDidFeedHandlerVerticle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VehicleConfigUpdateRepoHandler {

    @Autowired
    ConfigDidReceiverDao configDidReceiverDao;

    private Logger log = LoggerFactory.getLogger(VehicleConfigUpdateRepoHandler.class);

    public void removeProcessedEventFromTable() {
        ConfigDidReceiver configDidReceiver = configDidReceiverDao.findByStatus(VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
        if (null != configDidReceiver) {
            configDidReceiverDao.delete(configDidReceiver);
            log.info("Config receiver feed deleted successfully - " + configDidReceiver.getTraceId());
        } else {
            log.info("No records found with status - " + VehicleConfigUpdateConstants.CONFIG_RECV_IN_QUEUE_STATUS);
        }
    }

    public List<ConfigDidReceiver> fetchConfigDidFeedsWithStatus(String status) {
        List<ConfigDidReceiver> configDidFeedsList = configDidReceiverDao
                .findFirst10ByStatusOrderByCreatedDateAsc(status);
        return configDidFeedsList.isEmpty() ? null : configDidFeedsList;
    }

    public ConfigDidReceiver findByTraceId(String traceId) {
        ConfigDidReceiver didReceiver = configDidReceiverDao.findByTraceId(traceId);
        return didReceiver;
    }

    public void save(ConfigDidReceiver configDidReceiver) {
        ConfigDidReceiver saveObj = configDidReceiverDao.save(configDidReceiver);
        log.info("Config receiver feed stored successfully - " + saveObj.getId());
    }
}
