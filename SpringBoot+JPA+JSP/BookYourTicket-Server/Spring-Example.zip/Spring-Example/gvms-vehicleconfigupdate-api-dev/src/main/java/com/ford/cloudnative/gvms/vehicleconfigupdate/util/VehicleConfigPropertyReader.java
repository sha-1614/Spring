package com.ford.cloudnative.gvms.vehicleconfigupdate.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class VehicleConfigPropertyReader {

    @Value("${vehicleconfigupdate.rabbitmq.queue}")
    private String queueName;

    @Value("${vehicleconfigupdate.rabbitmq.routingkey}")
    private String routingKey;

    @Value("${vehicleconfigupdate.rabbitmq.exchange}")
    private String exchange;

    @Value("${spring.rabbitmq.host}")
    private String host;

    @Value("${spring.rabbitmq.virtual-host}")
    private String virtualHost;

    @Value("${spring.rabbitmq.port}")
    private String port;

    @Value("${spring.rabbitmq.server.port}")
    private String rmqServerPort;

    @Value("${spring.rabbitmq.username}")
    private String userName;

    @Value("${spring.rabbitmq.password}")
    private String password;

    @Value("${spring.rabbitmq.template.reply-timeout}")
    private Long replyTimeOut;

    @Value("${vehicleconfigupdate.request.failure.retry}")
    private Integer numberOfRetry;

    @Value("${vehicleconfigupdate.request.failure.interval.ms}")
    private Long failureIntervalInMs;

    @Value("${vehicleconfigupdate.rabbit.mq.depth.limit}")
    private Long maxQueueDepthLimit;

    @Value("${vehicleconfigupdate.request.alservice.endpoint}")
    private String aLServiceEndpoint;

    @Value("${vehicleconfigupdate.vertx.periodicrunner.delay}")
    private Long periodicRunnerDelayInMs;

    @Value("${vehicleconfigupdate.circuitbreaker.name}")
    private String circuitBreakerName;

    @Value("${vehicleconfigupdate.circuitbreaker.failurecount}")
    private int circuitBreakerFailureCount;

    @Value("${vehicleconfigupdate.circuitbreaker.failure-timeout}")
    private Long circuitBreakerTimeout;

    @Value("${vehicleconfigupdate.circuitbreaker.fallbackonfailure}")
    private boolean circuitBreakerFallBackOnFailure;

    @Value("${vehicleconfigupdate.circuitbreaker.reset-timeout}")
    private Long circuitBreakerResetTimeout;

    @Value("${vehicleconfigupdate.vertx.options.threadblock.interval}")
    private Long threadBlockInterval;

    @Value("${vehicleconfigupdate.vertx.options.eventloop.execution-time}")
    private Long eventLoopExecutionLimit;

    @Value("${vehicleconfigupdate.vertx.options.worker.execution-time}")
    private Long workerThreadExecutionLimit;

    @Value("${vehicleconfigupdate.vertx.options.handler.execution-time}")
    private Long loopHandlerExecutionLimit;

    public Integer getNumberOfRetry() {
        return numberOfRetry;
    }

    public Long getFailureIntervalInMs() {
        return failureIntervalInMs;
    }

    public String getALServiceEndpoint() {
        return aLServiceEndpoint;
    }

    public void setNumberOfRetry(Integer numberOfRetry) {
        this.numberOfRetry = numberOfRetry;
    }

    public void setFailureIntervalInMs(Long failureIntervalInMs) {
        this.failureIntervalInMs = failureIntervalInMs;
    }

    public void setALServiceEndpoint(String aLServiceEndpoint) {
        this.aLServiceEndpoint = aLServiceEndpoint;
    }

    public Long getReplyTimeOut() {
        return replyTimeOut;
    }

    public String getQueueName() {
        return queueName;
    }

    public String getRoutingKey() {
        return routingKey;
    }

    public String getExchange() {
        return exchange;
    }

    public String getHost() {
        return host;
    }

    public String getPort() {
        return port;
    }

    public String getVirtualHost() {
        return virtualHost;
    }

    public void setVirtualHost(String virtualHost) {
        this.virtualHost = virtualHost;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public Long getMaxQueueDepthLimit() {
        return maxQueueDepthLimit;
    }

    public void setMaxQueueDepthLimit(Long maxQueueDepthLimit) {
        this.maxQueueDepthLimit = maxQueueDepthLimit;
    }

    public void setPeriodicRunnerDelayInMs(Long periodicRunnerDelayInMs) {
        this.periodicRunnerDelayInMs = periodicRunnerDelayInMs;
    }

    public Long getPeriodicRunnerDelayInMs() {
        return periodicRunnerDelayInMs;
    }

    public String getRmqServerPort() {
        return rmqServerPort;
    }

    public void setRmqServerPort(String rmqServerPort) {
        this.rmqServerPort = rmqServerPort;
    }

    public int getCircuitBreakerFailureCount() {
        return circuitBreakerFailureCount;
    }

    public Long getCircuitBreakerTimeout() {
        return circuitBreakerTimeout;
    }

    public boolean getCircuitBreakerFallBackOnFailure() {
        return circuitBreakerFallBackOnFailure;
    }

    public Long getCircuitBreakerResetTimeout() {
        return circuitBreakerResetTimeout;
    }

    public String getCircuitBreakerName() {
        return circuitBreakerName;
    }

    public Long getThreadBlockInterval() {
        return threadBlockInterval;
    }

    public Long getEventLoopExecutionLimit() {
        return eventLoopExecutionLimit;
    }

    public Long getWorkerThreadExecutionLimit() {
        return workerThreadExecutionLimit;
    }

    public Long getLoopHandlerExecutionLimit() {
        return loopHandlerExecutionLimit;
    }
}
