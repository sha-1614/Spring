package com.ford.cloudnative.gvms.vehicleconfigupdate.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GvmsConfiguration implements Comparable {
    @SerializedName("vin")
    @Expose
    private String vin;
    @SerializedName("timestamp")
    @Expose
    private String timestamp;
    @SerializedName("oemConfig")
    @Expose
    private List<OemConfig> oemConfig = null;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public List<OemConfig> getOemConfig() {
        return oemConfig;
    }

    public void setOemConfig(List<OemConfig> oemConfig) {
        this.oemConfig = oemConfig;
    }

    @Override
    public int compareTo(Object newObject) {
        GvmsConfiguration gvmsConfiguration = (GvmsConfiguration) newObject;
        return this.getVin().compareTo(gvmsConfiguration.getVin());
    }
}
