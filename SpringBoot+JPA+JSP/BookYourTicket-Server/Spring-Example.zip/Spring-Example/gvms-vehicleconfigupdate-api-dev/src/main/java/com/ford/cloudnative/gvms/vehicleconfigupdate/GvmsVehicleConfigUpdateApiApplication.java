package com.ford.cloudnative.gvms.vehicleconfigupdate;

import com.ford.cloudnative.gvms.vehicleconfigupdate.util.VehicleConfigPropertyReader;
import com.ford.cloudnative.gvms.vehicleconfigupdate.verticle.ConfigDidConsolidaterVerticle;
import com.ford.cloudnative.gvms.vehicleconfigupdate.verticle.ConfigDidFeedHandlerVerticle;
import com.ford.cloudnative.gvms.vehicleconfigupdate.verticle.ConfigReceiverPeriodicRunner;
import com.ford.cloudnative.gvms.vehicleconfigupdate.verticle.RestServerVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


@SpringBootApplication
public class GvmsVehicleConfigUpdateApiApplication {


    @Autowired
    RestServerVerticle restServerVerticle;
    @Autowired
    ConfigReceiverPeriodicRunner configReceiverPeriodicRunner;
    @Autowired
    ConfigDidFeedHandlerVerticle configDidFeedHandlerVerticle;
    @Autowired
    VehicleConfigPropertyReader propertyReader;
    @Autowired
    ConfigDidConsolidaterVerticle configDidConsolidaterVerticle;

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(GvmsVehicleConfigUpdateApiApplication.class, args);
    }

    @PostConstruct
    public void deployVerticle() throws IOException, TimeoutException {
        Vertx vertx = Vertx.vertx(getVertxOptions());
        vertx.deployVerticle(restServerVerticle);
        vertx.deployVerticle(configReceiverPeriodicRunner);
        vertx.deployVerticle(configDidConsolidaterVerticle);
        vertx.deployVerticle(configDidFeedHandlerVerticle);
    }

    public VertxOptions getVertxOptions() {
        VertxOptions options = new VertxOptions();

        options.setBlockedThreadCheckInterval(propertyReader.getThreadBlockInterval());
        options.setBlockedThreadCheckIntervalUnit(TimeUnit.SECONDS);

        options.setMaxEventLoopExecuteTime(propertyReader.getEventLoopExecutionLimit());
        options.setMaxEventLoopExecuteTimeUnit(TimeUnit.MILLISECONDS);

        options.setMaxWorkerExecuteTime(propertyReader.getWorkerThreadExecutionLimit());
        options.setMaxWorkerExecuteTimeUnit(TimeUnit.SECONDS);

        options.setWarningExceptionTime(propertyReader.getLoopHandlerExecutionLimit());
        options.setWarningExceptionTimeUnit(TimeUnit.SECONDS);

        return options;
    }

}
