# gvms-vehicleconfigupdate-api
Vehicle config update consumer
